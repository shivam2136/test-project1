def fvt_food():
    print("Banana")

if __name__ == "__main__":
    fav_food()
    