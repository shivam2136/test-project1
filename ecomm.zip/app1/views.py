from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login , logout
from .models import products , CartItems,Categories,Subcategories
from django.db.models import Q

# Create your views here.

def index(request):
    data = products.objects.all()
    return render(request,"index.html",{'data':data})

def about(request):
    return render(request,"about.html")

def signup(request):
    if request.method == "POST":
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']

        if pass1 == pass2:
            try:
                user = User.objects.create_user(username=email,first_name=fname,last_name=lname,email=email,password=pass1)
                user.save()
                return redirect('signin')
            except Exception:
                error = 'User Already Exists'
                return render(request,'signup.html',{'error':error})
        else:
            error = 'Password and conform password does not match'
            return render(request,'signup.html',{'error':error})
    else:
        return render(request,"signup.html")

def signin(request):
    if request.method == "POST":
        uname = request.POST['uname']
        pass1 = request.POST['pass1']
        user = authenticate(username = uname, password = pass1 )
        if user is not None:
            login(request,user)
            return redirect("index")
        else:
            error = 'Invalid UserName or Password'
            return render(request,'signin.html', {'error':error})
    else:
        return render(request,"signin.html")
    
def signout(request):
    logout(request)
    return redirect("index")


def product_details(request,pid):
    data=products.objects.get(id=pid)
    return render(request,"product_details.html",{'data':data})

def addCart(request,pid):
    data = products.objects.get(id=pid)
    user = request.user if request.user.is_authenticated else None
    if user:
        cart_item , created = CartItems.objects.get_or_create(product = data, user = user)
    else:
        return redirect('signin')
    
    if not created:
        cart_item.quantity +=1
    else:
        cart_item.quantity =1
    cart_item.save()
    return redirect('viewCart')

def viewCart(request):
    if request.user.is_authenticated:
        Cart_item = CartItems.objects.filter(user = request.user)
    else:
        Cart_item = CartItems.objects.filter(user = None)
    context={}
    context['items']=Cart_item

    total_price = 0
    for x in Cart_item:
        total_price += (x.product.price*x.quantity)
    context['total']=total_price
    length = len(Cart_item)
    context['total_product']=length

    return render(request,"Cart.html",context)


def updateqty(request,val,pid):
    user = request.user
    c = CartItems.objects.filter(product_id=pid,user=user)
    if val == 0:
        if c[0].quantity>1:
            a = c[0].quantity-1
            c.update(quantity=a)
        

    else:
        a = c[0].quantity+1
        c.update(quantity=a)


    return redirect("viewCart")

def remove_product(request,pid):
    data = CartItems.objects.filter(product_id=pid,)
    data.delete()
    return redirect("viewCart")


def search_product(request):
    url = request.GET.get('product')
    if url == "electronics":
        subcategories=Subcategories.objects.filter(Q(name__iexact="printer") |Q(name__iexact="tv"));
        categories = Categories.objects.get(name="Electronics")
        data= products.objects.filter(categories__exact=categories)
        return render(request,"index.html",{'data':data,'sub':subcategories})
    elif url== "men":
        subcategories=Subcategories.objects.filter(Q(name__iexact="shoes") |Q(name__iexact="wallet")|Q(name__iexact="clothes"));
        categories = Categories.objects.get(name="Men")
        data= products.objects.filter(categories__exact=categories)
        return render(request,"index.html",{'data':data,'sub':subcategories})
    elif url == "women":
        subcategories=Subcategories.objects.filter(Q(name__iexact="sarees") |Q(name__iexact="dress")|Q(name__iexact="clothes"));
        categories = Categories.objects.get(name="Women")
        data= products.objects.filter(categories__exact=categories)
        return render(request,"index.html",{'data':data})
    elif url == "kids":
        categories = Categories.objects.get(name="Kids")
        data= products.objects.filter(categories__exact=categories)
        return render(request,"index.html",{'data':data,'sub':subcategories})
    elif url == "home and furniture":
        categories = Categories.objects.get(name="Home and Furniture")
        data= products.objects.filter(categories__exact=categories)
        return render(request,"index.html",{'data':data})
    elif url == "mobile and laptops":
        categories = Categories.objects.get(name="Mobile and Laptops")
        data= products.objects.filter(categories__exact=categories)
        return render(request,"index.html",{'data':data})
    

def subcategories(request,name):
    sub=Subcategories.objects.get(name__exact=name)
    data= products.objects.filter(categories__exact=sub)
    return render(request,"index.html",{'data':data})
    


