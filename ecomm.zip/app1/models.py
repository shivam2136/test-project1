from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Categories(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name
    
class Subcategories(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name
    
class products(models.Model):
    product_name =  models.CharField(max_length=100)
    desc = models.TextField(max_length=255)
    user_id = models.ForeignKey(User,on_delete=models.CASCADE,null=True,blank=True)
    categories = models.ForeignKey(Categories,on_delete=models.CASCADE)
    subcategories = models.ForeignKey(Subcategories,on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=7, decimal_places=2)
    image = models.ImageField(upload_to="product_images")
    objects = models.Manager() # The default manager.

    def __str__(self):
        return self.product_name   


class CartItems(models.Model):
    product = models.ForeignKey(products,on_delete=models.CASCADE)
    quantity = models.PositiveBigIntegerField(default=0)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
