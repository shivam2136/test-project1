from django.contrib import admin
from .models import Categories, Subcategories, products,CartItems

# Register your models here.

@admin.register(Categories)
class CategoriesAdmin(admin.ModelAdmin):
    list_display=["name"]

@admin.register(Subcategories)
class SubCategoriesAdmin(admin.ModelAdmin):
    list_display=["name"]

@admin.register(products)
class productsAdmin(admin.ModelAdmin):
    list_display=["product_name","price","categories","subcategories","desc","image"]


@admin.register(CartItems)
class CartAdmin(admin.ModelAdmin):
    list_display=["product", "quantity" , "user"]
 
